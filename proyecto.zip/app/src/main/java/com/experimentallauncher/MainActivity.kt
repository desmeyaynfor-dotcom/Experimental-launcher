package com.experimentallauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.content.IntentFilter
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ============================================================
//  BASE DE DATOS (notas + ajustes como favoritos y color)
// ============================================================
class LauncherDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "LauncherStorage.db", null, 1) {

    data class Note(val id: Long, val title: String, val content: String, val timestamp: Long)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT, content TEXT, timestamp INTEGER)"
        )
        db.execSQL(
            "CREATE TABLE app_data(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "setting_key TEXT UNIQUE, setting_value TEXT)"
        )
    }

    // No borramos datos al actualizar: aquí irían migraciones futuras.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insertNote(title: String, content: String, ts: Long): Long {
        val v = ContentValues().apply {
            put("title", title); put("content", content); put("timestamp", ts)
        }
        return writableDatabase.insert("notes", null, v)
    }

    fun updateNote(id: Long, title: String, content: String, ts: Long) {
        val v = ContentValues().apply {
            put("title", title); put("content", content); put("timestamp", ts)
        }
        writableDatabase.update("notes", v, "id = ?", arrayOf(id.toString()))
    }

    fun deleteNote(id: Long) {
        writableDatabase.delete("notes", "id = ?", arrayOf(id.toString()))
    }

    fun getNotes(): List<Note> {
        val list = mutableListOf<Note>()
        val c = readableDatabase.rawQuery(
            "SELECT id, title, content, timestamp FROM notes ORDER BY timestamp DESC", null
        )
        while (c.moveToNext()) {
            list.add(Note(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3)))
        }
        c.close()
        return list
    }

    fun setSetting(key: String, value: String) {
        val v = ContentValues().apply {
            put("setting_key", key); put("setting_value", value)
        }
        writableDatabase.insertWithOnConflict("app_data", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getSetting(key: String): String? {
        val c = readableDatabase.query(
            "app_data", arrayOf("setting_value"), "setting_key = ?", arrayOf(key),
            null, null, null
        )
        val result = if (c.moveToFirst()) c.getString(0) else null
        c.close()
        return result
    }
}

// ============================================================
//  PANTALLA PRINCIPAL DEL LAUNCHER
// ============================================================
class MainActivity : Activity() {

    data class AppInfo(val label: String, val pkg: String, val icon: Drawable)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var db: LauncherDatabaseHelper
    private var accent: Int = Color.parseColor("#B388FF")

    private var allApps: List<AppInfo> = emptyList()
    private var shownApps: List<AppInfo> = emptyList()

    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var searchBox: EditText
    private lateinit var appsAdapter: AppsAdapter
    private lateinit var dock: LinearLayout
    private lateinit var notesContainer: LinearLayout
    private lateinit var noteTitle: EditText
    private lateinit var noteBody: EditText
    private lateinit var deviceInfo: TextView
    private var editingNoteId: Long? = null

    private val pages = mutableListOf<View>()
    private val tabs = mutableListOf<TextView>()
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clockView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            dateView.text = SimpleDateFormat("EEEE d 'de' MMMM", Locale.getDefault())
                .format(now).replaceFirstChar { it.uppercase() }
            handler.postDelayed(this, 10_000)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
            filterApps(searchBox.text.toString())
            refreshDock()
            deviceInfo.text = deviceText()
        }
    }

    // ---------------------------------------------------------
    //  Ciclo de vida
    // ---------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LauncherDatabaseHelper(this)
        accent = try {
            Color.parseColor(db.getSetting("accent") ?: "#B388FF")
        } catch (e: Exception) {
            Color.parseColor("#B388FF")
        }

        window.statusBarColor = Color.parseColor("#1A0B2E")
        window.navigationBarColor = Color.parseColor("#000000")

        appsAdapter = AppsAdapter()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.parseColor("#1A0B2E"),
                    Color.parseColor("#0D0A1A"),
                    Color.parseColor("#000000")
                )
            )
        }

        root.addView(buildHeader())

        val host = FrameLayout(this)
        pages.add(buildAppsPage())
        pages.add(buildNotesPage())
        pages.add(buildLabPage())
        pages.forEach { host.addView(it, FrameLayout.LayoutParams(MATCH, MATCH)) }
        root.addView(host, LinearLayout.LayoutParams(MATCH, 0, 1f))

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.parseColor("#22FFFFFF"), 28)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        root.addView(dock, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(14), dp(6), dp(14), dp(6))
        })

        root.addView(buildTabBar())
        setContentView(root)

        loadApps()
        filterApps("")
        refreshDock()
        refreshNotes()
        showPage(0)

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        super.onDestroy()
    }

    // Al pulsar HOME volvemos a la pantalla de apps
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) {
            searchBox.setText("")
            showPage(0)
        }
    }

    // Un launcher no debe cerrarse con "atrás"
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (searchBox.text.isNotEmpty()) searchBox.setText("") else showPage(0)
    }

    // ---------------------------------------------------------
    //  Construcción de la interfaz
    // ---------------------------------------------------------
    private fun buildHeader(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(14), dp(22), dp(6))
        }
        val tag = label("⚗  EXPERIMENTAL LAB", 11f, accent, true).apply { letterSpacing = 0.25f }
        clockView = label("--:--", 52f, Color.WHITE, false).apply {
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        }
        dateView = label("", 14f, Color.parseColor("#B0FFFFFF"), false)
        box.addView(tag)
        box.addView(clockView)
        box.addView(dateView)
        return box
    }

    private fun buildTabBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#33000000"))
        }
        val names = listOf("📱 Apps", "📝 Notas", "🧪 Lab")
        names.forEachIndexed { i, name ->
            val t = label(name, 14f, Color.GRAY, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { showPage(i) }
            }
            tabs.add(t)
            bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return bar
    }

    private fun showPage(index: Int) {
        pages.forEachIndexed { i, v -> v.visibility = if (i == index) View.VISIBLE else View.GONE }
        tabs.forEachIndexed { i, t -> t.setTextColor(if (i == index) accent else Color.GRAY) }
        if (index != 0) hideKeyboard()
    }

    // ---------- Página: APPS ----------
    private fun buildAppsPage(): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        searchBox = EditText(this).apply {
            hint = "🔍  Buscar app..."
            setHintTextColor(Color.parseColor("#88FFFFFF"))
            setTextColor(Color.WHITE)
            background = rounded(Color.parseColor("#22FFFFFF"), 28)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) = filterApps(s?.toString().orEmpty())
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ ->
                shownApps.firstOrNull()?.let { launchApp(it.pkg) }
                true
            }
        }
        page.addView(searchBox, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            setMargins(dp(14), dp(6), dp(14), dp(8))
        })

        val grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(6)
            selector = ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(8), 0, dp(8), dp(8))
            clipToPadding = false
            adapter = appsAdapter
            onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
                launchApp(shownApps[pos].pkg)
            }
            onItemLongClickListener = AdapterView.OnItemLongClickListener { _, _, pos, _ ->
                showAppOptions(shownApps[pos]); true
            }
        }
        page.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return page
    }

    // ---------- Página: NOTAS ----------
    private fun buildNotesPage(): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(6))
        }

        noteTitle = styledEdit("Título", false)
        noteBody = styledEdit("Escribe tu idea experimental...", true)
        page.addView(noteTitle, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) })
        page.addView(noteBody, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(8)) })

        val save = pill("💾  Guardar nota") { saveNote() }
        page.addView(save, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(10)) })

        notesContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(notesContainer) }
        page.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return page
    }

    private fun saveNote() {
        val t = noteTitle.text.toString().trim()
        val b = noteBody.text.toString().trim()
        if (t.isEmpty() && b.isEmpty()) { toast("La nota está vacía"); return }
        val title = t.ifEmpty { "Sin título" }
        val id = editingNoteId
        if (id == null) db.insertNote(title, b, System.currentTimeMillis())
        else db.updateNote(id, title, b, System.currentTimeMillis())
        editingNoteId = null
        noteTitle.setText("")
        noteBody.setText("")
        hideKeyboard()
        refreshNotes()
        toast("Nota guardada ✔")
    }

    private fun refreshNotes() {
        notesContainer.removeAllViews()
        val notes = db.getNotes()
        if (notes.isEmpty()) {
            notesContainer.addView(label("Aún no hay notas. ¡Escribe la primera!", 14f, Color.parseColor("#88FFFFFF"), false))
            return
        }
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        for (n in notes) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Color.parseColor("#22FFFFFF"), 18)
                setPadding(dp(16), dp(12), dp(16), dp(12))
                setOnClickListener {
                    editingNoteId = n.id
                    noteTitle.setText(n.title)
                    noteBody.setText(n.content)
                    toast("Editando nota — pulsa Guardar")
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("¿Borrar nota?")
                        .setMessage(n.title)
                        .setPositiveButton("Borrar") { _, _ -> db.deleteNote(n.id); refreshNotes() }
                        .setNegativeButton("Cancelar", null)
                        .show()
                    true
                }
            }
            card.addView(label(n.title, 16f, accent, true))
            if (n.content.isNotEmpty()) {
                card.addView(label(n.content, 14f, Color.WHITE, false).apply {
                    maxLines = 4; ellipsize = TextUtils.TruncateAt.END
                })
            }
            card.addView(label(fmt.format(Date(n.timestamp)), 11f, Color.parseColor("#88FFFFFF"), false))
            notesContainer.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply {
                setMargins(0, 0, 0, dp(10))
            })
        }
    }

    // ---------- Página: LAB ----------
    private fun buildLabPage(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(14))
        }
        col.addView(label("Laboratorio del sistema", 18f, Color.WHITE, true))
        col.addView(label("Atajos a los permisos y ajustes que tu launcher puede pedir.", 12f, Color.parseColor("#99FFFFFF"), false).apply {
            setPadding(0, 0, 0, dp(10))
        })

        deviceInfo = label(deviceText(), 13f, Color.parseColor("#CCFFFFFF"), false).apply {
            background = rounded(Color.parseColor("#22FFFFFF"), 18)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        col.addView(deviceInfo, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, 0, 0, dp(10)) })

        fun add(text: String, action: () -> Unit) {
            col.addView(pill(text, action), LinearLayout.LayoutParams(MATCH, WRAP).apply {
                setMargins(0, 0, 0, dp(8))
            })
        }

        val me = Uri.parse("package:$packageName")
        add("⚙  Ajustes del sistema") { safeStart(Intent(Settings.ACTION_SETTINGS)) }
        add("🛠  Opciones de desarrollador") { safeStart(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
        add("🏠  Elegir launcher predeterminado") { safeStart(Intent(Settings.ACTION_HOME_SETTINGS)) }
        add("🪟  Permiso: dibujar sobre otras apps") {
            safeStart(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, me))
        }
        add("🔧  Permiso: modificar ajustes del sistema") {
            safeStart(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, me))
        }
        add("📂  Permiso: acceso a todos los archivos") {
            if (Build.VERSION.SDK_INT >= 30) {
                safeStart(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION, me))
            } else {
                requestPermissions(arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 1)
            }
        }
        add("🔔  Permiso: notificaciones") {
            safeStart(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        add("🎨  Cambiar color de acento") { pickAccent() }

        return ScrollView(this).apply { addView(col) }
    }

    private fun deviceText(): String =
        "Dispositivo: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Apps instaladas: ${allApps.size}"

    private fun pickAccent() {
        val names = arrayOf("Violeta", "Cian", "Verde neón", "Naranja", "Rosa", "Rojo")
        val hex = arrayOf("#B388FF", "#18FFFF", "#69F0AE", "#FFAB40", "#FF80AB", "#FF5252")
        AlertDialog.Builder(this)
            .setTitle("Color de acento")
            .setItems(names) { _, w ->
                db.setSetting("accent", hex[w])
                recreate()
            }
            .show()
    }

    // ---------------------------------------------------------
    //  Apps, favoritos y dock
    // ---------------------------------------------------------
    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    private fun filterApps(query: String) {
        val q = query.trim().lowercase()
        shownApps = if (q.isEmpty()) allApps else allApps.filter { it.label.lowercase().contains(q) }
        appsAdapter.notifyDataSetChanged()
    }

    private fun launchApp(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else toast("No se pudo abrir")
    }

    private fun getFavorites(): MutableList<String> =
        (db.getSetting("favorites") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun toggleFavorite(pkg: String) {
        val favs = getFavorites()
        if (favs.contains(pkg)) {
            favs.remove(pkg)
        } else {
            if (favs.size >= 5) { toast("El dock admite 5 favoritos"); return }
            favs.add(pkg)
        }
        db.setSetting("favorites", favs.joinToString(","))
        refreshDock()
    }

    private fun refreshDock() {
        dock.removeAllViews()
        val favApps = getFavorites().mapNotNull { p -> allApps.find { it.pkg == p } }
        if (favApps.isEmpty()) {
            dock.addView(label("Mantén pulsada una app → ⭐ Favorito", 12f, Color.parseColor("#99FFFFFF"), false).apply {
                setPadding(0, dp(14), 0, dp(14))
            })
            return
        }
        for (app in favApps) {
            val img = ImageView(this).apply {
                setImageDrawable(app.icon)
                setOnClickListener { launchApp(app.pkg) }
                setOnLongClickListener { toggleFavorite(app.pkg); true }
            }
            dock.addView(img, LinearLayout.LayoutParams(dp(52), dp(52)).apply {
                setMargins(dp(8), 0, dp(8), 0)
            })
        }
    }

    private fun showAppOptions(app: AppInfo) {
        val isFav = getFavorites().contains(app.pkg)
        val items = arrayOf(
            if (isFav) "☆ Quitar de favoritos" else "⭐ Añadir a favoritos",
            "ℹ Información de la app",
            "🗑 Desinstalar"
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(items) { _, which ->
                val uri = Uri.parse("package:${app.pkg}")
                when (which) {
                    0 -> toggleFavorite(app.pkg)
                    1 -> safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> safeStart(Intent(Intent.ACTION_DELETE, uri))
                }
            }
            .show()
    }

    inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = shownApps.size
        override fun getItem(position: Int) = shownApps[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cell = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(8), dp(4), dp(8))
                addView(ImageView(this@MainActivity), LinearLayout.LayoutParams(dp(52), dp(52)))
                addView(label("", 11f, Color.WHITE, false).apply {
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
            }
            val app = shownApps[position]
            (cell.getChildAt(0) as ImageView).setImageDrawable(app.icon)
            (cell.getChildAt(1) as TextView).text = app.label
            return cell
        }
    }

    // ---------------------------------------------------------
    //  Utilidades de UI
    // ---------------------------------------------------------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.parseColor("#0D0A1A"))
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL
        background = rounded(accent, 22)
        setPadding(dp(20), dp(14), dp(20), dp(14))
        setOnClickListener { onClick() }
    }

    private fun styledEdit(hintText: String, multiline: Boolean) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.parseColor("#88FFFFFF"))
        setTextColor(Color.WHITE)
        background = rounded(Color.parseColor("#22FFFFFF"), 18)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        if (multiline) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            gravity = Gravity.TOP
        } else {
            setSingleLine(true)
        }
    }

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { toast("No disponible en este teléfono") }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0) }
    }
}
